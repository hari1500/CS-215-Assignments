clear;
clc;
clear all;

n = [10,10^2,10^3,10^4,10^5,10^6,10^7,10^8,10^9];
rng(0);

for i = 1:7
    ni = n(i);
    a = single(2*rand(1,ni) -1);
    b = single(2*rand(1,ni) -1);
    count = sum( a.^2 + b.^2 < 1);
    fprintf('If number of sample points are 10^%d then estimate of pi is: %.6f \n',i,4*count/ni);
end

for i = 8:9
    ni = n(i);
    count = 0;
    while(ni > 10^7)
        a = single(2*rand(1,10^7) -1);
        b = single(2*rand(1,10^7) -1);
        count = count + sum( a.^2 + b.^2 < 1);
        ni = ni - 10^7;
    end
    a = single(2*rand(1,ni) -1);
    b = single(2*rand(1,ni) -1);
    count = count + sum( a.^2 + b.^2 < 1);
    fprintf('If number of sample points are 10^%d then estimate of pi is: %.6f \n',i,4*count/n(i));
end

m = 107870;
a = single(2*rand(1,m) -1);
b = single(2*rand(1,m) -1);
count = sum( a.^2 + b.^2 < 1);
fprintf('If number of sample points are %d then estimate of pi is: %.6f \n',m,4*count/m);