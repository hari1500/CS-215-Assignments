clear;
clc;
% tic;
images = loadMNISTImages('train-images-idx3-ubyte');
labels = loadMNISTLabels('train-labels-idx1-ubyte');
% toc;
images = double(images);
img_num = size(images,2);
count_occ = zeros(10,1);
mean_digits = zeros(10,28*28);
cov_digits = zeros(28*28,28*28,10);
% values = zeros(28*28,6000,10);
lambda1 = zeros(10,1);
eigv1=zeros(784,10);
C=zeros(784,10); 
indexfor = zeros(10,1);
% tic;
for i = 1:img_num
    curr_num = labels(i);
    mean_digits(curr_num+1,:) = mean_digits(curr_num+1,:) + images(:,i)';
    count_occ(curr_num+1) = count_occ(curr_num+1) + 1;
    x = count_occ(curr_num+1);
%     values(:,x,curr_num+1) = images(:,i)';
end
% toc; 
for i=1:10
    mean_digits(i,:)= mean_digits(i,:)/count_occ(i);
end

% tic;
for i=1:10
%     X = (values(:,1:count_occ(i),i) - repmat(mean_digits(i,:)',[ 1 , count_occ(i)]));
    Y = find(labels==i-1);
    temp = (mean_digits.');
    X = images(:,Y) - repmat(temp(:,i), 1,size(Y,1));
    cov_digits(:,:,i) = X*X' / count_occ(i);
end
% toc;
for i=1:10
    sumnow = 0;
   [V,L] = eig(cov_digits(:,:,i));

   [c, ind]=sort(diag(L),'descend');
   lambda1(i) = c(1);
   V = V(:,ind);
   eigv1(:,i) = V(:,1);
   C(:,i) = c;
   totc = sum(c);
%    Sum_eig(i) = sum(c);
   for kl=1:size(c)
       if sumnow >= 0.99*totc
           break;
       else
           sumnow = sumnow+c(kl);
       end
      
   end
    indexfor(i) = kl-1;
%    figure;
%    plot(1:784,c);
%    title(['Eigen Values of Covariance Matrix, digit= ' num2str(i-1)]);
   
%    figure;
   hold on;
   subplot(3,10,3*i-2);
   img1 = (mean_digits(i,:)' - sqrt(lambda1(i))*eigv1(:,i))/255;
   imshow(reshape(img1,28,28));
   title(['Fig1 digit' num2str(i-1)]);
   subplot(3,10,3*i-1);
   img2 = (mean_digits(i,:))'/255;
   imshow(reshape(img2,[ 28 28 ]));
   title(['Fig2 digit' num2str(i-1)]);
   subplot(3,10,3*i);
   img3 = ((mean_digits(i,:))' + sqrt(lambda1(i))*eigv1(:,i))/255;
   imshow(reshape(img3,28,28));
   title(['Fig3 digit' num2str(i-1)]);
   hold off;

end
col = rand(10,3);
figure;
% cmap = colormap(parula(10));
cmap = [ [0, 0.4470, 0.7410]; [0.8500, 0.3250, 0.0980]	;[0.9290, 0.6940, 0.1250]	;[0.4940, 0.1840, 0.5560];[0.4660, 0.6740, 0.1880];[0.3010, 0.7450, 0.9330];[0.6350, 0.0780, 0.1840];[1, 0, 0];[0.25, 0.25, 0.25];[0, 0.5, 0]]; 
for i=1:10
    
    hi = plot(1:784,C(:,i),'Color',cmap(i,:));
    
    h(i) = hi(1);
     if i == 1, hold on, end, 
   title('Eigen Values of Covariance Matrix');
end
ylabel('Eigen Values');
legend(h, {'0' '1' '2' '3' '4' '5' '6' '7' '8' '9'})
% ylim([1 10^3]);
figure;
plot(0:9,indexfor);
title('Number of significant modes of variation (99%) versus digit');
% toc;