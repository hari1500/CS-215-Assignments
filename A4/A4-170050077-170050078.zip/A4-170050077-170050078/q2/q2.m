% tic;
clear;
clc;
% clear all;
rng(0);
N = zeros(5,1);
N(1) = 10;N(2) = 100;N(3) = 1000;N(4) = 10000;N(5) = 100000;
MLcov = zeros(2,2,5);
C = [ 1.6250 , -1.9486 ; -1.9846 , 3.8750];
[EVe,EVa] = eig(C);
A = EVe*sqrt(EVa);
givenmu = [ 1 ; 2];
norgivmu = norm(givenmu);norgivcov = norm(C,'fro');
MLmu = zeros(2,1);
MLbpmu = zeros(5,100);
MLbpco = zeros(5,100);MLco = zeros(2,2);
% t = 1;
slope = EVe(2,2)/EVe(1,2);
x1 = 1; y1 = 2;
x = (1 - EVa(2,2)*cos(atan(slope))):0.05:1;
y = slope*(x - x1) + y1;

% tic;
for i= 1:5
    num = N(i);
    Xvar = zeros(2,num);
    for k = 1:100
%         for j = 1:num
%             W = randn(2,1);
%             Xvar(:,j) = givenmu + A*W;    
%         end
        W = randn(2,num);
        Xvar = repmat(givenmu,[1 num]) + A*W;
          
%           MLmu(1) = sum(Xvar(1,:))/num;
%           MLmu(2) = sum(Xvar(2,:))/num;
          MLmu = sum(Xvar,2)/num;
          MLbpmu(i,k) = norm(MLmu - givenmu)/norgivmu;          
          Xvar = Xvar - repmat(MLmu,[1,num]);
        MLco(:,:) = Xvar(:,:)* Xvar(:,:)';
        MLco(:,:) = MLco(:,:)/num;
        MLbpco(i,k) = norm(MLco - C,'fro')/norgivcov; 
        
        
    end
    figure;
    scatter(Xvar(1,:)+1,Xvar(2,:)+2,'g');
    xlabel('X_{1}');
    ylabel('X_{2}');
    title(['2D scatter plot of the generated data when N = 10^' num2str(i)]);
    hold on;
    plot(x,y);
    
end
figure;
% boxplot([MLbpmu(1,:);MLbpmu(2,:);MLbpmu(3,:);MLbpmu(4,:);MLbpmu(5,:)],[1*ones([1 100]), 2*ones([1 100]), 3*ones([1 100]), 4*ones([1 100]), 5*ones([1 100])]);
boxplot(MLbpmu');
title('Relative error between true and ML estimate of mean by norm');
xlabel('log_{10} N')
% ylabel('');
% ylim([0 0.4]);
figure;
% boxplot([MLbpco(1,:);MLbpco(2,:);MLbpco(3,:);MLbpco(4,:);MLbpco(5,:)],[1*ones([1 100]), 2*ones([1 100]), 3*ones([1 100]), 4*ones([1 100]), 5*ones([1 100])]);
boxplot(MLbpco');
xlabel('log_{10} N');
% ylabel('');
title('Relative error between true and ML estimate of Covariance by norm');
% toc;
% figure;
% scatter(
